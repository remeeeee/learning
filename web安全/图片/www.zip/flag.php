<?php

/*
# -*- coding: utf-8 -*-
# @Author: h1xa
# @Date:   2020-09-05 16:07:03
# @Last Modified by:   h1xa
# @Last Modified time: 2020-09-06 19:21:29
# @email: h1xa@ctfer.com
# @link: https://ctfer.com

*/
$flag="flag_here";

